
// ==========================================
// ORŌRA — COFFEE BEYOND ORDINARY
// Main JavaScript
// ==========================================

document.addEventListener("DOMContentLoaded", () => {

  // 1. PRELOADER
  const preloader = document.querySelector(".preloader");

  window.addEventListener("load", () => {
    if (preloader) {
      preloader.classList.add("hide");
    }
  });

  // 2. MOBILE NAVIGATION
  const menuToggle = document.querySelector(".menu-toggle");
  const navLinks = document.querySelector(".nav-links");

  if (menuToggle && navLinks) {
    menuToggle.addEventListener("click", () => {
      navLinks.classList.toggle("active");
      menuToggle.classList.toggle("active");
    });

    navLinks.querySelectorAll("a").forEach(link => {
      link.addEventListener("click", () => {
        navLinks.classList.remove("active");
        menuToggle.classList.remove("active");
      });
    });
  }

  // 3. NAVBAR SCROLL EFFECT
  const navbar = document.querySelector(".navbar");

  window.addEventListener("scroll", () => {
    if (navbar) {
      navbar.classList.toggle("scrolled", window.scrollY > 50);
    }
  });

  // 4. SMOOTH SCROLLING
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function (e) {
      const target = document.querySelector(this.getAttribute("href"));

      if (target) {
        e.preventDefault();
        target.scrollIntoView({
          behavior: "smooth",
          block: "start"
        });
      }
    });
  });

  // 5. SCROLL REVEAL ANIMATION
  const revealElements = document.querySelectorAll(
    ".reveal, .collection-card, .dimension-card, .story-content"
  );

  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });

    revealElements.forEach(element => observer.observe(element));
  } else {
    revealElements.forEach(element => element.classList.add("visible"));
  }

  // 6. CART DRAWER
  const bag = {};
  const cartCount = document.querySelector("#cartCount");
  const scrim = document.createElement("div");
  scrim.className = "cart-scrim";
  const drawer = document.createElement("aside");
  drawer.className = "cart-drawer";
  drawer.setAttribute("aria-label", "Shopping bag");
  drawer.innerHTML = `
    <div class="cart-head"><h3>Your Bag</h3><button class="cart-close" aria-label="Close bag">✕</button></div>
    <div class="cart-list"></div>
    <div class="cart-foot">
      <div class="cart-total"><span>TOTAL</span><strong>Rs. 0</strong></div>
      <button class="primary-button cart-checkout">CHECKOUT ↗</button>
    </div>`;
  document.body.append(scrim, drawer);
  const list = drawer.querySelector(".cart-list");
  const fmt = n => "Rs. " + n.toLocaleString("en-US");

  function renderCart() {
    const names = Object.keys(bag);
    let qty = 0, total = 0;
    list.innerHTML = names.length ? names.map(n => {
      qty += bag[n].qty; total += bag[n].qty * bag[n].price;
      return `<div class="cart-item"><div><h4>${n}</h4><span>${fmt(bag[n].price)}</span></div>
        <div class="cart-qty"><button data-act="minus" data-n="${n}" aria-label="Less">−</button><b>${bag[n].qty}</b><button data-act="plus" data-n="${n}" aria-label="More">+</button></div></div>`;
    }).join("") : '<p class="cart-empty">Your bag is empty.<br>Add a blend from the collection.</p>';
    drawer.querySelector(".cart-total strong").textContent = fmt(total);
    if (cartCount) cartCount.textContent = qty;
  }
  const openCart = o => { drawer.classList.toggle("open", o); scrim.classList.toggle("open", o); };
  document.querySelector("#bagButton")?.addEventListener("click", () => openCart(true));
  scrim.addEventListener("click", () => openCart(false));
  drawer.querySelector(".cart-close").addEventListener("click", () => openCart(false));
  document.addEventListener("keydown", e => e.key === "Escape" && openCart(false));
  list.addEventListener("click", e => {
    const b = e.target.closest("button[data-act]"); if (!b) return;
    const it = bag[b.dataset.n];
    it.qty += b.dataset.act === "plus" ? 1 : -1;
    if (it.qty <= 0) delete bag[b.dataset.n];
    renderCart();
  });
  drawer.querySelector(".cart-checkout").addEventListener("click", () => {
    if (!Object.keys(bag).length) return showToast("Your bag is empty");
    Object.keys(bag).forEach(k => delete bag[k]); renderCart(); openCart(false);
    showToast("Thank you! This is a demo checkout.");
  });
  document.querySelectorAll(".add-button").forEach(btn => {
    btn.addEventListener("click", () => {
      const name = btn.dataset.product;
      const price = parseInt(btn.closest(".product-card").querySelector("strong").textContent.replace(/\D/g, ""), 10);
      bag[name] = bag[name] || { price, qty: 0 };
      bag[name].qty++;
      renderCart();
      showToast(`${name} added to your bag`);
    });
  });
  renderCart();

  // 7. COFFEE MATCHER
  const picks = {
    bold:   "Eclipse Blend: dark chocolate, caramel, bold.",
    smooth: "Sunrise Blend: honey and citrus, silky and bright.",
    fruity: "Sunrise Blend: floral, citrus and juicy.",
    deep:   "Midnight Blend: hazelnut, cocoa, intense."
  };
  let mood = null;
  const moods = document.querySelectorAll(".mood-button");

  moods.forEach(b => b.addEventListener("click", () => {
    mood = b.dataset.mood;
    moods.forEach(x => x.classList.toggle("active", x === b));
  }));

  document.querySelector("#matchButton")?.addEventListener("click", () => {
    const box = document.querySelector("#recommendation");
    if (box) box.textContent = mood ? picks[mood] : "Pick a mood first.";
  });

  // 7b. NEWSLETTER FORM
  const newsletterForm = document.querySelector("#newsletterForm");

  newsletterForm?.addEventListener("submit", event => {
    event.preventDefault();
    showToast("Welcome to the ORŌRA circle!");
    newsletterForm.reset();
  });

  // 8. TOAST NOTIFICATION
  function showToast(message) {
    let toast = document.querySelector("#toast");

    if (!toast) {
      toast = document.createElement("div");
      toast.id = "toast";
      document.body.appendChild(toast);
    }

    toast.textContent = message;
    toast.classList.add("show");

    setTimeout(() => {
      toast.classList.remove("show");
    }, 3000);
  }

  // 9. CURRENT YEAR IN FOOTER
  const yearElement = document.querySelector("#year");

  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }


  // 10. SCROLL PROGRESS BAR
  const bar = document.createElement("div");
  bar.className = "scroll-progress";
  document.body.append(bar);

  // 11. PARALLAX (scroll + mouse)
  const heroEl = document.querySelector(".hero");
  const heroBg = document.querySelector(".hero-background");
  const heroContent = document.querySelector(".hero-content");
  const orbitEl = document.querySelector(".hero-visual");
  let ticking = false;
  function onScroll() {
    ticking = false;
    const y = window.scrollY, h = document.documentElement;
    bar.style.transform = `scaleX(${y / (h.scrollHeight - innerHeight || 1)})`;
    if (y < innerHeight * 1.2) {
      if (heroBg) heroBg.style.translate = `0 ${y * 0.22}px`;
      if (heroContent) heroContent.style.translate = `0 ${y * -0.1}px`;
    }
  }
  window.addEventListener("scroll", () => {
    if (!ticking) { ticking = true; requestAnimationFrame(onScroll); }
  }, { passive: true });
  onScroll();

  heroEl?.addEventListener("mousemove", e => {
    const x = e.clientX / innerWidth - 0.5, y = e.clientY / innerHeight - 0.5;
    if (orbitEl) orbitEl.style.translate = `${x * -28}px ${y * -28}px`;
  });

  // 12. ACTIVE NAV LINK
  const navAnchors = [...document.querySelectorAll(".nav-links a")];
  const secObs = new IntersectionObserver(entries => {
    entries.forEach(en => {
      if (en.isIntersecting) {
        navAnchors.forEach(a => a.classList.toggle("active", a.getAttribute("href") === "#" + en.target.id));
      }
    });
  }, { rootMargin: "-45% 0px -50% 0px" });
  navAnchors.forEach(a => {
    const s = document.querySelector(a.getAttribute("href"));
    if (s) secObs.observe(s);
  });

  // 13. CUSTOM CURSOR (desktop only)
  if (matchMedia("(pointer: fine)").matches && !matchMedia("(prefers-reduced-motion: reduce)").matches) {
    const ring = document.createElement("div");
    ring.className = "cursor-ring";
    document.body.append(ring);
    let mx = innerWidth / 2, my = innerHeight / 2, rx = mx, ry = my;
    window.addEventListener("mousemove", e => { mx = e.clientX; my = e.clientY; ring.classList.add("on"); });
    document.addEventListener("mouseleave", () => ring.classList.remove("on"));
    (function loop() {
      rx += (mx - rx) * 0.18; ry += (my - ry) * 0.18;
      ring.style.transform = `translate(${rx}px, ${ry}px) translate(-50%, -50%)`;
      requestAnimationFrame(loop);
    })();
    document.addEventListener("mouseover", e => {
      ring.classList.toggle("hover", !!e.target.closest("a, button, .product-card, .dimension-card, input"));
    });
  }

  // 14. MAGNETIC BUTTONS
  if (matchMedia("(pointer: fine)").matches) {
    document.querySelectorAll(".primary-button, .outline-button, .bag-button").forEach(el => {
      el.addEventListener("mousemove", e => {
        const r = el.getBoundingClientRect();
        el.style.translate = `${(e.clientX - r.left - r.width / 2) * 0.22}px ${(e.clientY - r.top - r.height / 2) * 0.35}px`;
      });
      el.addEventListener("mouseleave", () => { el.style.translate = ""; });
    });
  }


  // 15. HERO HEADLINE WORD REVEAL
  const h1 = document.querySelector(".hero-content h1");
  if (h1) {
    let n = 0;
    const wrap = node => {
      [...node.childNodes].forEach(ch => {
        if (ch.nodeType === 3) {
          const frag = document.createDocumentFragment();
          ch.textContent.split(/(\s+)/).forEach(t => {
            if (!t.trim()) { frag.append(" "); return; }
            const o = document.createElement("span"), i = document.createElement("span");
            o.className = "w"; i.textContent = t; i.style.setProperty("--i", n++);
            o.append(i); frag.append(o);
          });
          ch.replaceWith(frag);
        } else if (ch.nodeType === 1) wrap(ch);
      });
    };
    wrap(h1);
  }

  // 16. PRODUCT QUICK VIEW
  const profiles = {
    "Eclipse Blend":  { origin: "Sumatra & Brazil",    roast: "Dark roast",   bars: { Intensity: 90, Body: 85, Sweetness: 55, Acidity: 25 } },
    "Sunrise Blend":  { origin: "Ethiopia & Kenya",    roast: "Light roast",  bars: { Intensity: 45, Body: 50, Sweetness: 70, Acidity: 90 } },
    "Midnight Blend": { origin: "Colombia & Guatemala", roast: "Dark roast",  bars: { Intensity: 80, Body: 90, Sweetness: 60, Acidity: 35 } }
  };
  const qv = document.createElement("div");
  qv.className = "qv";
  qv.innerHTML = `<div class="qv-box" role="dialog" aria-modal="true">
    <button class="qv-close" aria-label="Close">✕</button>
    <div class="qv-img"><img alt=""></div>
    <div class="qv-info">
      <span class="eyebrow"></span><h3></h3><p class="qv-notes"></p>
      <div class="qv-bars"></div>
      <div class="qv-row"><strong></strong><button class="primary-button qv-add">ADD TO BAG +</button></div>
    </div></div>`;
  document.body.append(qv);
  let qvCard = null;
  const closeQV = () => qv.classList.remove("open");
  function openQV(card) {
    qvCard = card;
    const name = card.querySelector("h3").textContent;
    const p = profiles[name] || { origin: "Single estate", roast: "Medium roast", bars: { Intensity: 60, Body: 60, Sweetness: 60, Acidity: 60 } };
    qv.querySelector("img").src = card.querySelector("img").src;
    qv.querySelector("img").alt = name;
    qv.querySelector(".eyebrow").textContent = `${p.roast} · ${p.origin}`.toUpperCase();
    qv.querySelector("h3").textContent = name;
    qv.querySelector(".qv-notes").textContent = card.querySelector(".product-info p").textContent;
    qv.querySelector("strong").textContent = card.querySelector(".product-info strong").textContent;
    qv.querySelector(".qv-bars").innerHTML = Object.entries(p.bars).map(([k]) =>
      `<div class="qv-bar"><span>${k}</span><div><i></i></div></div>`).join("");
    qv.classList.add("open");
    setTimeout(() => qv.querySelectorAll(".qv-bar i").forEach((el, i) => el.style.width = Object.values(p.bars)[i] + "%"), 250);
  }
  document.querySelectorAll(".product-card .product-image, .product-card h3").forEach(el => {
    el.style.cursor = "pointer";
    el.addEventListener("click", () => openQV(el.closest(".product-card")));
  });
  qv.addEventListener("click", e => { if (e.target === qv) closeQV(); });
  qv.querySelector(".qv-close").addEventListener("click", closeQV);
  qv.querySelector(".qv-add").addEventListener("click", () => { qvCard.querySelector(".add-button").click(); closeQV(); });
  document.addEventListener("keydown", e => e.key === "Escape" && closeQV());

});
